/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

//EXERCISE 2.5
	//Use the handler name EXTI0_1_IRQHandler to declare the handler fuction.
	void EXTI0_1_IRQHandler(void) {
		
		//Toggle both the green and orage LEDs (PC8 & PC9) in the EXTI interrupt handler.
		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_8 | GPIO_PIN_9); //Toggle the output state of PC8 (Orange LED) and PC9 (Green LED).
		
		//Clear the appropriate flag for input line 0 in the EXTI pending register within the handler.
		__HAL_GPIO_EXTI_CLEAR_IT(EXTI0_1_IRQn);
		
//EXERCISE 2.6
		//Add a delay loop of roughly 1-2 seconds to the EXTI interrupt handler.
		//HAL_Delay(1000); //Delay 1000ms
		
		int i;
		
		for(i = 0; i < 1500000; i++) {
		}
		
		//Add a second LED toggle so that the green and orange LEDs should exchange once before and after the delay loop.
		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_8 | GPIO_PIN_9); //Toggle the output state of PC8 (Orange LED) and PC9 (Green LED).
//END EXERCISE 2.6
	}
//END EXERCISE 2.5

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  //Reset of all peripherals, Initializes the Flash interface and the Systick.
  HAL_Init();

  //Configure the system clock.
  SystemClock_Config();
	
//EXERCISE 2.1
	__HAL_RCC_GPIOC_CLK_ENABLE(); //Enable the GPIOC clock in the RRC.
//END EXERCISE 2.1
	
//EXERCISE 2.2
	__HAL_RCC_GPIOA_CLK_ENABLE(); //Enable the GPIOA clock in the RRC.
//END EXERCISE 2.2

//EXERCISE 2.3
	//1. Use the RCC to enable the peripheral clock to the SYSCFG peripheral.
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGCOMPEN;
//END EXERCISE 2.3



//EXERCISE 2.1
	//1. Initialize all of the LED pins in the main function.
	
	//Set up a configuration struct to pass to the initialization function.
	GPIO_InitTypeDef initStr = {GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9, GPIO_MODE_OUTPUT_PP, GPIO_SPEED_FREQ_LOW,GPIO_NOPULL};
	
	//Initialize pins PC6 (red LED), PC7 (blue LED), PC8 (orange LED), & PC9 (green LED). 
	HAL_GPIO_Init(GPIOC, &initStr);
	
	//2. Set the green LED (PC9) high (we will use this later in the lab).
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET); //Start PC9 (green LED) high.
//END EXERCISE 2.1
	
//EXERCISE 2.2
	//1. Configure the button pin (PA0) to input-mode at low-speed, with the internal pull-down resistor enabled.
	GPIOA->MODER = 0; //Set PA0 button pin (bits 1:0) to input-mode.
	GPIOA->OSPEEDR = 0; //Set PA0 button pin (bits 1:0) to low-speed.
	GPIOA->PUPDR |= (1<<1); //Enables the PA0 button pin (bits 1:0) to pull-down (10).
	
	//2. Pin PA0 connects to the EXTI input line 0 (EXTI0).
	SYSCFG->EXTICR[1] &= ~SYSCFG_EXTICR1_EXTI0_PA;
	
	//3. Enable/unmask interrupt generation on EXTI input line 0 (EXTI0).
	EXTI->IMR |= EXTI_IMR_IM0;
	
	//4. Configure the EXTI input line 0 to have a rising-edge trigger.
	EXTI->RTSR |= EXTI_RTSR_RT0;
//END EXERCISE 2.2

//EXERCISE 2.3
	//4. Configure the multiplexer to route PA0 to the EXTI input line 0 (EXTI0). 
	SYSCFG->EXTICR[1] |= ~SYSCFG_EXTICR1_EXTI0_PA;
//END EXERCISE 2.3

//EXERCISE 2.4
	//3. Enable the selected EXTI interrupt by passing its defined name to the NVIC_EnableIRQ() function.
	NVIC_EnableIRQ(EXTI0_1_IRQn);
	
	//4. Set the priority for the interrupt to 1 (high-priority) with the NVIC_SetPriority() function.
	NVIC_SetPriority(EXTI0_1_IRQn, 2);
//END EXERCISE 2.4

//EXERCISE 2.7
	//sET sYStICK INTERRUPT PRIORITY TO 2 (medium priority).
	NVIC_SetPriority(SysTick_IRQn, 3);
	
  while (1)
  {
//EXERCISE 2.1
    //Toggle the red LED (PC6) with a moderately-slow delay (400-600ms) in the infinite loop.
		//The red LED is used to indicate whether the main loop is executing.
		HAL_Delay(500); //Delay 500ms.
		
		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_6); //Toggle the output state of PC6 (red LED).
//END EXERCISE 2.1
  }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

