03/24/17
Brian Burton
Lucas Idstrom

Assignment #8 - Histogram

Histogram Project Summary:

In assignment eight, we were to implement a Poker Game, Texas Hold'em, and find the odds of receiving all
of the different Poker hand rankings.

Design Decisions: Followed the instructions given to the best of our ability. We decided that in the Odds
				  Class that the methods could only use five or seven cards. 

Problems Encountered and Their Solutions: Had a hard time with finding a way to find the rank of a hand 
										  of Cards. It definitely took most of our time. It still is not
										  working perfectly but it is pretty close. We would have fixed 
										  it if we knew what the problem was.