04/07/17
Brian Burton
Lisa Richardson

Assignment #10 - Hashing

The Hashing Project Summary:

In assignment ten, we were to crack passwords using hash keys and values in a hash table. 

Design Decisions: Followed the instructions given to the best of our ability.

Problems Encountered and Their Solutions: Had a hard time with implementing the Chaining class. We had 
										  a lot of bugs in that class that we had to take out. The cracking
										  class was also kind of difficult just because we were having a 
										  hard time understanding what a few of the methods were suppose to 
										  do. Overall it was mostly straight forward.