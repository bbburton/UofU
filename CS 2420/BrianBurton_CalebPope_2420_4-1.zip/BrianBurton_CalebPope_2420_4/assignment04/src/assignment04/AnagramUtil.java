/**
 * Your Name: Brian Burton
 * Your UID: u1038667
 * The Date: 02/09/17
 * The Class Number: CS 2420
 * The Assignment Number: #4
 * 
 * I pledge that the work done here was my own and that I have learned how to write 
 * this program, such that I could throw it out and restart and finish it in a timely 
 * manner. I am not turning in any work that I cannot understand, describe, or recreate. 
 * I further acknowledge that I contributed substantially to all code handed in and vouch 
 * for it's authenticity. Brian Burton.
 *
 */

package assignment04;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeSet;

public class AnagramUtil {
	
  /**
   * This method returns the sorted version of the input string.
   *
   * @param word : a string presumed to be out of order
   * @return     : a copy of the input string, but in a sorted order
   */
  public static String sort(String word) {
    // We assume a 1 character string is already sorted.
    if (word.length() == 1) { return word.toLowerCase(); }

    char[]      char_array;
    Character[] character_array;

    // Copy to a char array, then a Character array,
    //   so we can pass an object array of the input string to our insertion sort.
    char_array      = word.toLowerCase().toCharArray();
    character_array = new Character[char_array.length];

    // Convert char array to Character array so we can pass it into insertionSort
    for (int index = 0; index < char_array.length; index++) {
      character_array[index] = new Character(char_array[index]);
    }

    // Call the insertion sort method on our object Character array.
    //   Also pass in an anonymous class comparator (ooo fancy).
    //Arrays.sort(character_array, new Comparator<Character>() {
    insertionSort(character_array, new Comparator<Character>() {
      @Override
      public int compare(Character left, Character right) {
        return left.compareTo(right);
      }
    });

    // Convert Character array back to char array so we can convert it back to a string easily.
    for (int index = 0; index < character_array.length; index++) {
      char_array[index] = character_array[index];
    }

    return new String(char_array);
  }

  /**
   * This generic method sorts the input array using the well known insertion sort algorithm and
   * the input Comparator object.
   *
   * @param array            : any generic array/string/etc that needs sorted
   * @param alpha_comparator : a comparator used to sort
   */
  public static <T> void insertionSort(T[] array, Comparator<? super T> alpha_comparator) {
    int tmp_index;
    T   temp_var;

    for (int index = 1; index < array.length; index++) {
      // tmp_index allows us to follow the item down the array as it searches for it's place.
      tmp_index = index;
      // In other words, while the item needs shifted to the left.
      while (alpha_comparator.compare(array[tmp_index - 1], array[tmp_index])  >  0) {
        // Swap item to the left.
        temp_var             = array[tmp_index];
        array[tmp_index]     = array[tmp_index - 1];
        array[tmp_index - 1] = temp_var;

        // Follow the item down the array as it searches for it's place.
        tmp_index--;
        // Stop if we hit the end.
        if (tmp_index < 1) { break; }
      }
    }
  }

  /**
   * This method returns true if the two input strings are anagrams of each other, otherwise returns false.
   *
   * @param string1  : a word to compare to string2
   * @param string2  : a word to compare to string1
   * @return boolean : true if they are anagrams, false if they're not.
   */
  public static boolean areAnagrams(String string1, String string2) {
    String anagram1 = sort(string1);
    String anagram2 = sort(string2);

    if (anagram1.equals(anagram2)) { return true; }

    return false;
  }

  /**
   * Finds and returns the largest number of anagrams from a list of words passed in,
   *   or an empty string array if there are no anagrams.
   *
   *
   * Algorithm:
   *   pull word out of array
   *       sort characters in word
   *       compare word to existing sets looking for anagrams
   *         sort letters in first item of each set
   *         compare sorted word to sorted word from set
   *         if it does not match any set, make a new one and make note of it's position in the list
   *       enter into set specified by the position index variable
   *
   *     get set size and return the largest one
   *       find size from each set
   *       compare to the largest size so far
   *       return largest set as an array
   *
   *
   * @param string_array : array of strings containing words that may or may not be anagrams of each other
   * @return             : array of [first] largest set of anagrams from the array passed in
   */
  public static String[] getLargestAnagramGroup(String[] string_array) {
    int                        set_number        = 0;
    int                        largest_set_size  = 0;
    int                        current_set_size  = 0;
    String                     current_word;
    String[]                   the_chosen_ones;
    TreeSet<String>            largest_set;
    ArrayList<TreeSet<String>> anagram_sets_list = new ArrayList<TreeSet<String>>();

    // loop through list of Sets searching for the one that matches our word
    for (int index = 0; index < string_array.length; index++) {
      current_word = string_array[index];
      set_number = find_matching_set(current_word, anagram_sets_list);

      // Did not find a list that contained anagrams of our word
      if (set_number == -1) {
        anagram_sets_list.add(new TreeSet<String>());
        set_number = anagram_sets_list.size() - 1;
      }

      // add word to the specified set
      anagram_sets_list.get(set_number).add(current_word);
    }

    // Find set containing the most anagrams, storing it's index in set_number.
    for (int set_index = 0; set_index < anagram_sets_list.size(); set_index++) {
      current_set_size = anagram_sets_list.get(set_index).size();

      // If we find ones that's bigger than the currently know largest set, make note of it's position.
      if (current_set_size > largest_set_size) {
        largest_set_size = current_set_size;
        set_number = set_index;
      }
    }

    // Return an empty array if there is less than 2 words in the largest set of anagrams.
    if (largest_set_size < 2) {
      return new String[] { };
    }

    // Manually convert the set into a string array because we aren't allowed to cast it to a String[].
    largest_set = anagram_sets_list.get(set_number);
    the_chosen_ones = new String[largest_set.size()];
    for (int index = 0; index < largest_set.size(); index++) {
      the_chosen_ones[index] = largest_set.toArray()[index].toString().toLowerCase();
    }

    return the_chosen_ones;
  }

  /**
   *
   * Behaves the same as the previous method, but reads the list of
   * words from the input filename. It is assumed that the file contains
   * one word per line. If the file does not exist or is empty, the method
   * returns an empty array because there are no anagrams.
   *
   * @param filepath  : relative path to file filled with potential anagrams as specified above
   * @return String[] : array of anagrams, or empty if no anagrams were found
   */
  public static String[] getLargestAnagramGroup(String filepath) {
    BufferedReader reader = null;
    String words_from_file = "";
    String line;

    // Read file, return empty string array if there is no file (no words specified).
    try {
      reader = new BufferedReader(new FileReader(filepath));

      // Read lines from file, return empty string array if file is empty (no words specified).
      try {
        // Add each word (line) to a string separating each word by spaces.
        while ((line = reader.readLine()) != null) {
          words_from_file += line;
          words_from_file += " ";
        }
      } catch (IOException e) {
        return new String[] { };
      }
    } catch (FileNotFoundException e) {
      return new String[] { };
    } finally {
      try {
        reader.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }

    // Call the other method that has all the logic and return it's output.
    //   Split the space separated list of words into an array to be passed in.
    return getLargestAnagramGroup(words_from_file.split(" "));
  }

  /**
   * This method returns the index of a set in the list that contains anagrams to `word`.
   * In other words, it finds a home suitable for a new word.
   *
   * @param word                             : word that needs a home
   * @param anagram_sets_list                : a list of homes
   * @return integer between -1 and infinity : index of the matching home from the list passed in
   */
  public static int find_matching_set(String word, ArrayList<TreeSet<String>> anagram_sets_list) {
    String          first_word_in_set;
    TreeSet<String> current_set;

    // Loop through list of Sets
    for (int set_number = 0; set_number < anagram_sets_list.size(); set_number++) {
      // skip if the set at `set_number` happens to be empty
      if ( (current_set = anagram_sets_list.get(set_number)).isEmpty() ) { continue; }

      // the first word in the set would be an accurate representation of the anagrams in the set.
      first_word_in_set = current_set.first().toString();

      // return `set_number` that contains anagrams to the word passed in.
      if (areAnagrams(first_word_in_set, word)) { return set_number; }
    }

    // no matching set's were found.
    return -1;
  }
}