/**
 * Your Name: Brian Burton
 * Your UID: u1038667
 * The Date: 02/09/17
 * The Class Number: CS 2420
 * The Assignment Number: #4
 * 
 * I pledge that the work done here was my own and that I have learned how to write 
 * this program, such that I could throw it out and restart and finish it in a timely 
 * manner. I am not turning in any work that I cannot understand, describe, or recreate. 
 * I further acknowledge that I contributed substantially to all code handed in and vouch 
 * for it's authenticity. Brian Burton.
 *
 */

package assignment04;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.TreeSet;

import org.junit.Test;

public class Anagram_Tests {
  @Test
  public void test_sort_for_strings() {
    assertEquals("a", AnagramUtil.sort("A"));
    assertEquals("esy", AnagramUtil.sort("Yes"));
    assertEquals("aailmn", AnagramUtil.sort("Animal"));
    assertEquals("chloos", AnagramUtil.sort("ScHoOl"));
  }

  @Test
  public void test_insertion_sort() {
    Comparator<Character> alpha_comparator = new Comparator<Character>() {
      @Override
      public int compare(Character left, Character right) {
        return left.compareTo(right);
      }
    };

    Comparator<Integer> numeric_comparator = new Comparator<Integer>() {
      @Override
      public int compare(Integer left, Integer right) {
        return left.compareTo(right);
      }
    };

    Comparator<String> string_comparator = new Comparator<String>() {
      @Override
      public int compare(String left, String right) {
        return left.compareTo(right);
      }
    };

    Character[] characters;
    Character[] char_answer;
    Integer[]   integers;
    Integer[]   int_answer;
    String[]    strings;
    String[]    string_answer;

    // characters
    characters  = new Character[] {'y', 'e', 's'};
    char_answer = new Character[] {'e', 's', 'y'};
    AnagramUtil.insertionSort(characters, alpha_comparator);
    assertEquals(char_answer, characters);

    characters  = new Character[] {'t', 'e', 'a', 'r'};
    char_answer = new Character[] {'a', 'e', 'r', 't'};
    AnagramUtil.insertionSort(characters, alpha_comparator);
    assertEquals(char_answer, characters);

    characters  = new Character[] {'t'};
    char_answer = new Character[] {'t'};
    AnagramUtil.insertionSort(characters, alpha_comparator);
    assertEquals(char_answer, characters);

    // integers
    integers   = new Integer[] {4, 2, 6, 7};
    int_answer = new Integer[] {2, 4, 6, 7};
    AnagramUtil.insertionSort(integers, numeric_comparator);
    assertEquals(int_answer, integers);

    integers   = new Integer[] {0, -5, 66, 7};
    int_answer = new Integer[] {-5, 0, 7, 66};
    AnagramUtil.insertionSort(integers, numeric_comparator);
    assertEquals(int_answer, integers);

    integers   = new Integer[] {7};
    int_answer = new Integer[] {7};
    AnagramUtil.insertionSort(integers, numeric_comparator);
    assertEquals(int_answer, integers);

    // Strings
    strings       = new String[] {"something", "else"};
    string_answer = new String[] {"else", "something"};
    AnagramUtil.insertionSort(strings, string_comparator);
    assertEquals(string_answer, strings);

    strings       = new String[] {"an", "array", "of", "strings", "goes", "here"};
    string_answer = new String[] {"an", "array", "goes", "here", "of", "strings"};
    AnagramUtil.insertionSort(strings, string_comparator);
    assertEquals(string_answer, strings);

    strings       = new String[] {"else"};
    string_answer = new String[] {"else"};
    AnagramUtil.insertionSort(strings, string_comparator);
    assertEquals(string_answer, strings);
  }

  @Test
  public void test_are_anagrams() {
    String word1;
    String word2;

    word1 = "act";
    word2 = "cat";
    assertEquals(true, AnagramUtil.areAnagrams(word1, word2));

    word1 = "String";
    word2 = "ARray";
    assertEquals(false, AnagramUtil.areAnagrams(word1, word2));

    word1 = "calipers";
    word2 = "replicas";
    assertEquals(true, AnagramUtil.areAnagrams(word1, word2));
  }

  @Test
  public void test_getLargestAnagramGroup_array() {
    String[] two_anagrams1 = new String[] { "cat", "act", "bat" };
    String[] two_anagrams2 = new String[] { "fun", "bun", "none", "unb", "unf", "non" };
    String[] no_anagrams   = new String[] { "cat", "spider", "bat" };
    String[] same_word     = new String[] { "cat", "cat" };
    String[] one_word      = new String[] { "cat" };
    String[] empty_array   = new String[] { };

    String[] resulting_array = AnagramUtil.getLargestAnagramGroup(two_anagrams1);

    assertEquals(new String[] { "act", "cat" }, AnagramUtil.getLargestAnagramGroup(two_anagrams1));
    assertEquals(new String[] { "fun", "unf" }, AnagramUtil.getLargestAnagramGroup(two_anagrams2));
    assertEquals(new String[] { },              AnagramUtil.getLargestAnagramGroup(no_anagrams));
    assertEquals(new String[] { },              AnagramUtil.getLargestAnagramGroup(empty_array));
    assertEquals(new String[] { },              AnagramUtil.getLargestAnagramGroup(same_word));
    assertEquals(new String[] { },              AnagramUtil.getLargestAnagramGroup(one_word));
    assertEquals(true,                          Arrays.asList(resulting_array).containsAll(Arrays.asList("cat", "act")));
  }

  @Test
  public void test_getLargestAnagramGroup_string() {
    assertEquals(new String[] { "caters", "reacts", "carets", "caster", "crates", "recast", "traces" },
      AnagramUtil.getLargestAnagramGroup("Resources/words"));
  }

  @Test
  public void test_find_matching_set_helper_method() {
    String                     word                                   = "crates";
    ArrayList<TreeSet<String>> multi_set_that_contains_anagrams       = new ArrayList<TreeSet<String>>();
    ArrayList<TreeSet<String>>       set_that_contains_anagrams       = new ArrayList<TreeSet<String>>();
    ArrayList<TreeSet<String>>       set_that_doesnt_contain_anagrams = new ArrayList<TreeSet<String>>();
    ArrayList<TreeSet<String>>       set_that_is_empty                = new ArrayList<TreeSet<String>>();

    multi_set_that_contains_anagrams.add(new TreeSet<String>());
    multi_set_that_contains_anagrams.add(new TreeSet<String>());
    multi_set_that_contains_anagrams.add(new TreeSet<String>());
    multi_set_that_contains_anagrams.add(new TreeSet<String>());
    set_that_contains_anagrams.      add(new TreeSet<String>());
    set_that_doesnt_contain_anagrams.add(new TreeSet<String>());
    set_that_is_empty.               add(new TreeSet<String>());
    multi_set_that_contains_anagrams.get(1).addAll(Arrays.asList("cat", "act"));
    multi_set_that_contains_anagrams.get(2).addAll(Arrays.asList("traces", "caster", "reacts"));
    multi_set_that_contains_anagrams.get(3).addAll(Arrays.asList("bun", "unb", "nub"));
    set_that_contains_anagrams.      get(0).addAll(Arrays.asList("traces", "caster", "reacts"));
    set_that_doesnt_contain_anagrams.get(0).addAll(Arrays.asList("cat", "act"));

    assertEquals(0,  AnagramUtil.find_matching_set(word, set_that_contains_anagrams));
    assertEquals(2,  AnagramUtil.find_matching_set(word, multi_set_that_contains_anagrams));
    assertEquals(-1, AnagramUtil.find_matching_set(word, set_that_doesnt_contain_anagrams));
    assertEquals(-1, AnagramUtil.find_matching_set(word, set_that_is_empty));
  }
}
