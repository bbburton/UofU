/**
 * Your Name: Brian Burton
 * Your UID: u1038667
 * The Date: 02/09/17
 * The Class Number: CS 2420
 * The Assignment Number: #4
 * 
 * I pledge that the work done here was my own and that I have learned how to write 
 * this program, such that I could throw it out and restart and finish it in a timely 
 * manner. I am not turning in any work that I cannot understand, describe, or recreate. 
 * I further acknowledge that I contributed substantially to all code handed in and vouch 
 * for it's authenticity. Brian Burton.
 *
 */

package assignment04;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Main {

	static public void main(String[] args) {

		long start_time;

		start_time = System.nanoTime();

		// Warming up the System.
		while (System.nanoTime() - start_time < 1_000_000_000) {
		}
		
		//timing_areAnagrams();
		
		timing_getLargestAnagramGroup();
	}

	public static void timing_areAnagrams() {

		ArrayList<String[]> list_of_words = new ArrayList<String[]>();

		list_of_words.add(read_file_to_array("Resources/words_english_100_words"));

		list_of_words.add(read_file_to_array("Resources/words_english_1_000_words"));

		//list_of_words.add(read_file_to_array("Resources/words_english_10_000_words"));

		//list_of_words.add(read_file_to_array("Resources/words_english_50_000_words"));

		//list_of_words.add(read_file_to_array("Resources/words_english_100_000_words"));

		String[] words;

		long start_time, end_time, mid_time, run_count;

		long average_of_the_averages = 0;

		long average_time[] = new long[list_of_words.size()];

		start_time = System.nanoTime();

		for (int list_number = 0; list_number < list_of_words.size(); list_number++) {
			words = list_of_words.get(list_number);

			start_time = System.nanoTime();

			for (int index = 0; index < words.length - 1; index++) {
				AnagramUtil.areAnagrams(words[index], words[index + 1]);
			}

			mid_time = System.nanoTime();

			for (int index = 0; index < words.length - 1; index++) {
			}

			end_time = System.nanoTime();

			average_time[list_number] = ((mid_time - start_time) - (end_time - mid_time)) / (words.length - 1);

		}

		for (int index = 0; index < list_of_words.size(); index++) {

			average_of_the_averages += average_time[index];
		}

		average_of_the_averages /= list_of_words.size();

		System.out.println("The average time for areAnagrams method is " + average_of_the_averages + " nano seconds.");
	}

	public static void timing_getLargestAnagramGroup() {

		ArrayList<String[]> list_of_words = new ArrayList<String[]>();

		//list_of_words.add(read_file_to_array("Resources/words_english_100_words"));

		//list_of_words.add(read_file_to_array("Resources/words_english_1_000_words"));

		//list_of_words.add(read_file_to_array("Resources/words_english_10_000_words"));

		//list_of_words.add(read_file_to_array("Resources/words_english_50_000_words"));

		list_of_words.add(read_file_to_array("Resources/words_english_100_000_words"));

		String[] words;

		long start_time, end_time, mid_time, run_count;

		long average_of_the_averages = 0;

		long average_time[] = new long[list_of_words.size()];

		start_time = System.nanoTime();

		for (int list_number = 0; list_number < list_of_words.size(); list_number++) {
			words = list_of_words.get(list_number);

			start_time = System.nanoTime();

			AnagramUtil.getLargestAnagramGroup(words);

			end_time = System.nanoTime();

			average_time[list_number] = (end_time - start_time) / (words.length);

		}

		for (int index = 0; index < list_of_words.size(); index++) {

			average_of_the_averages += average_time[index];
		}

		average_of_the_averages /= list_of_words.size();

		System.out.println("The average time for getLargestAnagramGroup(String[]) method is " + average_of_the_averages + " nano seconds.");
	}

	public static String[] read_file_to_array(String file_path) {
		BufferedReader reader = null;
		String words_from_file = "";
		String line;

		// Read file, return empty string array if there is no file (no words
		// specified).
		try {
			reader = new BufferedReader(new FileReader(file_path));

			// Read lines from file, return empty string array if file is empty
			// (no words specified).
			try {
				// Add each word (line) to a string separating each word by
				// spaces.
				while ((line = reader.readLine()) != null) {
					words_from_file += line;
					words_from_file += " ";
				}
			} catch (IOException e) {
				return new String[] {};
			}
		} catch (FileNotFoundException e) {
			return new String[] {};
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();

			}
		}

		return words_from_file.split(" ");
	}
}
