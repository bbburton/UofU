public class DemoEnum
{
   public static void main(String[] args) {
 
   }
}