public class DemoArray
{
   public static void main(String[] args) {
   
   }
}