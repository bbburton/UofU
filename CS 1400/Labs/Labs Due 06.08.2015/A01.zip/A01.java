/*******************************************************
* Name:
* Assignment: A01
*******************************************************/

public class A01
{
	public static void main(String[] args)
	{
		// part1
		System.out.print("x x x");
		System.out.print("x o x");
		System.out.print("x x x");

		// part2
		
	}
}