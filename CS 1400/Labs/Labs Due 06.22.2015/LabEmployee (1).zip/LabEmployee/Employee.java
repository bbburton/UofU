public class Employee
{
   // fields
	
	// constructors
 
   // methods	

}