public class Country
{
	// fields
		
	// constructor
	
	// methods
	
	@Override
	public String toString()
	{
		return null;
	}
}