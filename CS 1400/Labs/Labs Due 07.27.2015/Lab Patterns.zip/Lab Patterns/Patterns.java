public class Patterns
{
   public static void patterns1(int size)
   { 
      for(int x = 1; x <= size; x++)
      {
         System.out.print("::");
         System.out.printf("%s", "@");
         System.out.print("...");
         System.out.println();
      }
   }
   
   public static void patterns2(int size)
   { 
      for(int x = 1; x <= size; x++)
      {
         System.out.print("::");
         System.out.printf("%s", "@");
         System.out.print("...");
         System.out.println();
      }
   }
   
   public static void patterns3(int size)
   { 
      for(int x = 1; x <= size; x++)
      {
         System.out.print("::");
         System.out.printf("%s", "@");
         System.out.print("...");
         System.out.println();
      }
   }
   
   public static void patterns4(int size)
   { 
      for(int x = 1; x <= size; x++)
      {
         System.out.print("::");
         System.out.printf("%s", "@");
         System.out.print("...");
         System.out.println();
      }
   }
}