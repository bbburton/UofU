/*******************************************************
* Sample Code - do not modify
* Assignment: A03
*******************************************************/

public class Car
{
   // fields
   private String make;
   private String model;
   private String owner;
   
  // contructors
   
   // methods
   public String getMake()
   {
      return make;
   }  
   
   public String getModel()
   {
      return model;
   }
  
   public String getOwner()
   {
      return owner;
   }
   
   public void setMake(String newMake)
   {
      make = newMake;
   }
   
   public void setModel(String newModel)
   {
      model = newModel;
   }
   
   public void setOwner(String newOwner)
   {
      owner = newOwner;
   }
}