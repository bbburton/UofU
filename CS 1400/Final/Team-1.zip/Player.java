public class Player
{
   String name;
   int wins=0;
   int losses=0;
}