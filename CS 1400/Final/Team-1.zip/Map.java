import java.util.Random;

public class Map
{
	// private field(s)
   int size;
	Tile gameMap[][] = new Tile[50][50]; //Max size of map is 50
   
   // constructor(s)
	public Map(int input)   // input is the size of map the player selected
   {
      size = input;
      
      createMap(); //assigns each tile a bomb or a safe character 
      refineMap(); // each tile determines if there is a bomb nearby and then hides map
   }
   
   public void createMap() { // nested for loop to fill in the array with either a bomb or a safe character
      for (int i = 0; i<size; i++)
      {
         for (int j=0; j<size; j++)
         {
            gameMap[j][i]= new Tile();
         }
      }
   }
      
   public void refineMap() { //determines which tiles are adjacent to tiles and hides map
      for (int i = 0; i<size; i++)
      {
         for (int j=0; j<size; j++)
         {
            int counter =0; // keeps track of adjacent bombs
            if (gameMap[j][i].getValue()!= 'B') //if the current tile isn't a bomb
            {
               if (j!=0) //if we aren't on the far left side of the  map
                  if (gameMap[j-1][i].getValue()== 'B') //if the tile to the left of the current tile is a bomb,
                     counter++;                         //add to counter
               if (j!=size-1) // if we aren't on the far right side of the map
                  if (gameMap[j+1][i].getValue()== 'B') //if the tile to the right of the current tile is a bomb,
                     counter++;                         //add to counter
               if (i!=0) //if we aren't on the top of the map
                  if (gameMap[j][i-1].getValue()== 'B') //of the tile above the current tile is a bomb,
                     counter++;                         //add to counter
               if (i!=size-1) //if we aren't at the bottom of the map
                  if (gameMap[j][i+1].getValue()== 'B') //if the tile below the current tile is a bomb,
                     counter++;                         //add to counter

//B: if current tile isn't in the top left corner of the map
//       if the tile above and to the left of the current tile is a bomb,
         //add to counter


//B: if current tile isn't in the top right corner of the map
//       if the tile above and to the right of the current tile is a bomb,
         //add to counter


//B: if current tile isn't in the bottom left corner of the map
//       if the tile below and to the left of the current tile is a bomb,
         //add to counter


//B: if current tile isn't in the bottom right corner of the map
//       if the tile below and to the right of the current tile is a bomb,
         //add to counter

                  switch (counter) //I used a switch here because i couldn't remember if the assignment required it
                  {
                     case 1:
                        gameMap[j][i].setValue('1');
                        break;
                     case 2:
                        gameMap[j][i].setValue('2');
                        break;
                     case 3:
                        gameMap[j][i].setValue('3');
                        break;
                     case 4:
                        gameMap[j][i].setValue('4');
                        break;
                     case 5:
                        gameMap[j][i].setValue('5');
                        break;
                     case 6:
                        gameMap[j][i].setValue('6');
                        break;
                     case 7:
                        gameMap[j][i].setValue('7');
                        break;
                     case 8:
                        gameMap[j][i].setValue('8');
                        break;
                     case 9:
                        gameMap[j][i].setValue('9');
                        break;                        
                 }
                                                      
            }
                         gameMap[j][i].toggle();// now that we've determined if the tile is a bomb or counted the number of adjacent bombs, we want to hide the tile from the player            
         }
      }
   }      

   public void printMap() { // prints current map. It's basically a nested loop to print each tile in the 2D array
         System.out.print("   ");
         for (int kk=1; kk<=size; kk++) // print column number at the top
         {
            System.out.printf("%d ", kk);         
         }
         System.out.println();

         System.out.print("  ");
         for (int tt=1; tt<=size; tt++)
         {
            System.out.printf("__", tt);         
         }
         System.out.println();

         
      for (int i = 0; i<size; i++)
      {
            System.out.printf("%-2d|", i+1);//print row number at the left         
         
         for (int j=0; j<size; j++)
         {
            System.out.printf("%c ", gameMap[j][i].getValue()); //print tile
         }
         System.out.println();
      }
   }

   public boolean input(int row, int column) //determines if player input hits a bom
   {
      gameMap[row][column].toggle(); //unhides the tile
      if (gameMap[row][column].getValue()=='B') //if current tile is a bomb
      {
         System.out.print("You Hit a Bomb");
         return false; //false will trigger loss
      }
      else
         return true; //true will allow the player to keep playing
      
   }
   
   public boolean win() // determines if win condition has been met
   {
   
//J or B: if win condition has been met, return true
//J or B: if win condition has not been met, return false and game will continue  
      return false;
   }


}
