import java.util.Scanner;


public class MineSweeper
{

	public static boolean PlayGame()
   {
      Scanner input = new Scanner(System.in);
      System.out.print("Please enter map size (Maximum of 50): ");
      int selection = input.nextInt();   
      Map myMap = new Map(selection); //create map of size selection
      

    boolean alive = true;
      do 
      {
         myMap.printMap(); //prints current map
         int row=0;
         int column=0;
         boolean validInput=false;
         
         while (validInput==false) // player selects row
         {   
            System.out.printf("Enter Row (1-%d): ", selection);
            row = input.nextInt()-1;
            if (row>=0&&row<=selection) // determine if selection is valid
               validInput=true;
            else
               System.out.printf("Invalid input.%n");
         }
         
         validInput=false;   
         while (validInput==false) // player selects column
         {
            System.out.printf("Enter Column (1-%d): ", selection);
            column = input.nextInt()-1;
            if (column>=0&&column<=selection) // determine if selection is valid
               validInput=true;
            else
               System.out.printf("Invalid input%n");

         }
         alive = myMap.input(column, row);  //finds out what tile is and returns false if a bomb is hit       

//J or B: create a win condition using myMap.win() seen below
//         if (myMap.win())   //if win          
//             return true;   //immediately exit program with true to signify win
         
      }  while (alive);
      System.out.println();
         myMap.printMap(); //prints ending map
   
   
   return false; //if bomb was triggered, false signifies loss
   }




	public static void main(String[] args)
	{
        Scanner input = new Scanner(System.in);

        System.out.printf("Welcome to MiNeSwEePer!%n");
        System.out.print("Please enter your name: ");
        String player = input.nextLine();

//J: Create new Player class with player as the name.

        int newGame = 1;
        Scanner inputInt = new Scanner(System.in);
        do
        {
            boolean win = PlayGame();
            if (win)
            {
//J: Add to win counter in Player class
            }
            else
            {
//J: Add to loss counter in Player class            
            }            
            
            System.out.printf("%nPress 1 to play another game or 2 to quit: ");
            newGame = inputInt.nextInt();
        }
        while (newGame == 1);
//J: print your score is: Retrieve score from Player class
        System.out.println("Good Bye!");
   }      
}