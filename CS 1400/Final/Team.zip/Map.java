import java.util.Random;

public class Map
{
	// private field(s)
   int size;
	Tile gameMap[][] = new Tile[50][50];
   
   // constructor(s)
	public Map(int input)
   {
      size = input;
      
      createMap();
      refineMap();
   }
   
   public void createMap() {
      for (int i = 0; i<size; i++)
      {
         for (int j=0; j<size; j++)
         {
            gameMap[j][i]= new Tile();
         }
      }
   }
      
   public void refineMap() {
      for (int i = 0; i<size; i++)
      {
         for (int j=0; j<size; j++)
         {
            int counter =0;
            if (gameMap[j][i].getValue()!= 'B') 
            {
               if (j!=0)
                  if (gameMap[j-1][i].getValue()== 'B')
                     counter++;
               if (j!=size-1)
                  if (gameMap[j+1][i].getValue()== 'B')
                     counter++;
               if (i!=0)
                  if (gameMap[j][i-1].getValue()== 'B')
                     counter++;
               if (i!=size-1)
                  if (gameMap[j][i+1].getValue()== 'B')
                     counter++; 
                  switch (counter)
                  {
                     case 1:
                        gameMap[j][i].setValue('1');
                        break;
                     case 2:
                        gameMap[j][i].setValue('2');
                        break;
                     case 3:
                        gameMap[j][i].setValue('3');
                        break;
                     case 4:
                        gameMap[j][i].setValue('4');
                        break;
                 }
                                                      
            }
                         gameMap[j][i].toggle();            
         }
      }
   }      

   public void printMap() {
      for (int i = 0; i<size; i++)
      {
         for (int j=0; j<size; j++)
         {
            System.out.printf("%c ", gameMap[j][i].getValue());
         }
         System.out.println();
      }
   }

   public boolean input(int row, int column)
   {
      gameMap[row][column].toggle();
      if (gameMap[row][column].getValue()=='B')
      {
         System.out.print("You Hit a Bomb");
         return false;
      }
      else
         return true;
      
   }

}
