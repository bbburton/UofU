import java.util.Scanner;

public class MineSweeper
{
	public static void main(String[] args)
	{
      boolean alive = true;
      Scanner input = new Scanner(System.in);
      System.out.print("Please enter map size (Maximum of 50): ");
      int selection = input.nextInt();   
      Map myMap = new Map(selection);
      
      do 
      {
         myMap.printMap();
         
         System.out.print("Enter Row: ");
         int row = input.nextInt();
         System.out.print("Enter Column: ");
         int column = input.nextInt();
         alive = myMap.input(column, row);         
      }  while (alive);
      System.out.println();
         myMap.printMap();
         
   }      
}