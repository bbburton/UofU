import java.util.Random;

public class Tile
{
	// private field(s)
	private char value;
	boolean isHidden;
   
   // constructor(s)
	public Tile()
   {
      isHidden=false;
      Random rand = new Random();
      if (isBomb(rand.nextInt(10))) 
         value = 'B';
      else
         value = 'S';
   }
   
   public boolean isBomb()
   {
      if (value == 'B')
         return true;
      else
         return false;
   }
   
   public static boolean isBomb(int random)
   {
      if (random<2)
         return true;
      else
         return false;   
   }
   
   public char getValue()
   {
      if (isHidden)
         return '*';
      else
         return value;
   }
   
   public void toggle() 
   {
      if (isHidden)
         isHidden=false;
      else
         isHidden=true;
   }
   
   public void setValue(char newValue)
   {
      value = newValue;
   }
}

